package clases;

public interface AccionPicotear
{
	public void picotear();
}
