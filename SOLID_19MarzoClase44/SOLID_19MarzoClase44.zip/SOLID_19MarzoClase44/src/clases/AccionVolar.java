package clases;

public interface AccionVolar 
{
	public void volar();
}
