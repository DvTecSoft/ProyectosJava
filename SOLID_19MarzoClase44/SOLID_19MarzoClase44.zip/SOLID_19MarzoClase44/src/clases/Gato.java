package clases;

public class Gato extends Animal 
{

	@Override
	public void ruido() 
	{
		System.out.println("Miau");
	}

}
