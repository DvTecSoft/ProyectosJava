package clases;

public class Perro extends Animal  
{
	@Override
	public void ruido() 
	{
		System.out.println("Guau");
	}

}
